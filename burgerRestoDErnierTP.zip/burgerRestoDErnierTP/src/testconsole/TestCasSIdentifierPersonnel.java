package testconsole;

import controleur.ControlCreerProfil;
import controleur.ControlSIdentifier;
import modele.ProfilUtilisateur;
import vueconsole.BoundarySIdentifierPersonnel;

public class TestCasSIdentifierPersonnel {

	public static void main(String[] args) {

		// Mise en place de l'environnement
		ControlCreerProfil controlCreerProfil = new ControlCreerProfil();
		controlCreerProfil.creerProfil(ProfilUtilisateur.GERANT, "Martin",
				"Victor", "gmv");

		// Initialisation controleur du cas & cas Inclus/etendu
		ControlSIdentifier controlSIdentifier = new ControlSIdentifier();
		// Initialisation vue du cas
		BoundarySIdentifierPersonnel boundarySIdentifierPersonnel = new BoundarySIdentifierPersonnel(
				controlSIdentifier);
		// Lancement du cas
		int numPersonnel = boundarySIdentifierPersonnel.sIdentifierPersonnel();

		// Verification de la bonne r�alisation du cas
		System.out.println("VERIFICATION");
		System.out.println("numero du personnel = " + numPersonnel);
		System.out.println(controlSIdentifier.visualiserBDUtilisateur());

		// Resultat du test
		// Veuilliez entrer votre login
		// Victor.Martin
		// Veuilliez entrer votre mot de passe
		// gmv
		// VERIFICATION
		// numero du personnel = 0
		// BDPersonnel [listePersonnel={0=Personnel [gerant=true, nom=Martin,
		// prenom=Victor, login=Victor.Martin, mdp=gmv, connecte=true]}]
		// BDClient [listeClient={}]
	}
}
