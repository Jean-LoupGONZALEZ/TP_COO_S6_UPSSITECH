package controleur;

import java.beans.PropertyChangeListener;

import modele.BDCommande;
import modele.ProfilUtilisateur;
import modele.PropertyName;

public class ControlVisualiserCommandeJour {
	
	private BDCommande bdCommande = BDCommande.getInstance();
	private ControlVerifierIdentification controlVerifierIdentification;
	
	public void setListener(String name, PropertyChangeListener listener) {
		this.bdCommande.addPropertyChangeListener(name, listener);
	}
	
	public ControlVisualiserCommandeJour(ControlVerifierIdentification controlVerifierIdentification) {
		this.controlVerifierIdentification = controlVerifierIdentification;
	}
	
	public boolean verifierIdentification(int numProfilCuisinier, ProfilUtilisateur profilUtilisateur) {
		return controlVerifierIdentification.verifierIdentification(profilUtilisateur, numProfilCuisinier);
	}

}
