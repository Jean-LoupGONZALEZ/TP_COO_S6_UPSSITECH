package vueGraphique;



import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controleur.ControlCommander;
import controleur.ControlEnregistrerCoordonneesBancaires;

public class FrameClient extends JFrame {
	// Les attributs metiers (ex : numClient)
	private int numClient;
	// Declaration et creation des elements graphiques (JLabel)
	// Declaration et creation de la barre de menu (MenuBar) 
	MenuBar menuBar = new MenuBar();
	// Declaration et creation des differents panels
	private JPanel panAccueil = new JPanel();
	private JPanel panContents = new JPanel();
	private PanHistorique panHistorique = new PanHistorique();
	private PanModifierProfil panModifierProfil = new PanModifierProfil();
	private PanCommander panCommander;
	// Declaration et creation du gestionnaire des cartes (CardLayout)
	private CardLayout cartes = new CardLayout();

	// Le constructeur
	public FrameClient (int numClient, ControlCommander controlCommander, ControlEnregistrerCoordonneesBancaires controlEnregistrerCoordonneesBancaires) {
		// initialisation des attributs metiers
		this.numClient = numClient;
		// mise en forme de la frame (titre, dimension, ...)
		setTitle("BurgerResto");
		setSize(900,400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		// initialisation des differents panels : appel a leur methode d'initialisation
		PanEnregistrerCoordonneesBancaires panEnregistrerCoordonneesBancaires = new PanEnregistrerCoordonneesBancaires(controlEnregistrerCoordonneesBancaires);
		panCommander = new PanCommander(controlCommander, panEnregistrerCoordonneesBancaires);
		panCommander.initialisation();
		panHistorique.initialisation();
		panModifierProfil.initialisation();
		// ajout des pannels dans le ContentPane de la Frame
		panContents.setLayout(cartes);
		panContents.add(panCommander, "COMMANDER");
		panContents.add(panHistorique,"HISTORIQUE");
		panContents.add(panModifierProfil,"MODIFIER PROFIL");
		panCommander.add(panEnregistrerCoordonneesBancaires,
				"ENREGISTRER_COORDONNEES_BANCAIRE");
		getContentPane().add(panContents);
		// mise en page : mises en place des cartes
		initialisationAcceuil();
		// mise en place du menu 
		initialisationMenu();
		setMenuBar(menuBar);
		// appel a la methode d'initialisation du menu
		// appel a la methode d'initialisation de la page d'accueil (optionnel)
		panEnregistrerCoordonneesBancaires.initialisation();
		this.setVisible(true);
	}


	private void initialisationMenu() {
		MenuItem commander = new MenuItem("Commander");
		commander.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent event) {
				panCommander.commander(numClient);
				cartes.show(panContents, "COMMANDER");
				}     
			});
		MenuItem historique = new MenuItem("Historique");
		historique.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent event) {
				cartes.show(panContents, "HISTORIQUE");
				}     
			});
		MenuItem modifierProfil = new MenuItem("Modifier profil");
		modifierProfil.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent event) {
				cartes.show(panContents, "MODIFIER PROFIL");
				}     
			});
		Menu menuMonCompte = new Menu("Mon compte");
		menuMonCompte.add(commander);
		menuMonCompte.add(historique);
		menuMonCompte.add(modifierProfil);
		Menu menuDeconnexion = new Menu("Deconnexion");
		menuBar.add(menuMonCompte);
		menuBar.add(menuDeconnexion);
	}

	private void initialisationAcceuil(){
		panAccueil.setBackground(Color.ORANGE);       
		JLabel texteAccueil = new JLabel("Bienvenue à Burger Resto"); 
		texteAccueil.setFont(new Font("Calibri", Font.BOLD, 24)); 
		panAccueil.add(texteAccueil); 
		panAccueil.setVisible(true); 
		panContents.add(panAccueil, "ECRAN_ACCUEIL"); 
		cartes.show(panContents, "ECRAN_ACCUEIL");    
	}
}

