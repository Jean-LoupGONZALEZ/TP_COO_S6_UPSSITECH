package modele;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.HashMap;
import java.util.Map;

public class BDCommande {
	
	//attributs
	private Map<Integer,Commande>mapCommande;
	private PropertyChangeSupport support = new PropertyChangeSupport(this);
	
	//constructeur privé
	private BDCommande() {
		this.mapCommande = new HashMap<Integer, Commande>();
	}
	
	//holder
	private static class BDCommandeHolder {
		private final static BDCommande instance = new BDCommande();
	}
	
	//getInstance
	public static BDCommande getInstance() {
		return BDCommandeHolder.instance;
	}
	
	//methodes
	public int enregistrerCommande(int numClient, Hamburger hamburger, Accompagnement accompagnement, Boisson boisson) {
		Commande commande = new Commande(numClient, hamburger, accompagnement, boisson);
		int numeroCommande = commande.getNumeroCommandeAttribuee();
		mapCommande.put(numeroCommande, commande);
		String[] label = new String[4];
		label[0] = String.valueOf(numeroCommande);
		label[1] = hamburger.getNom();
		label[2] = accompagnement.getNom();
		label[3] = boisson.getNom();
		support.firePropertyChange(PropertyName.ENREGISTRER_COMMANDE.toString(),null,label);
		return numeroCommande;
		
	}
	public void viderCommandeJour() {
		
	}
	public Commande supprimerCommande(int numCommande) {
		return null;
	}
	public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener ) {
		support.addPropertyChangeListener(propertyName, listener);
	}
	
}
