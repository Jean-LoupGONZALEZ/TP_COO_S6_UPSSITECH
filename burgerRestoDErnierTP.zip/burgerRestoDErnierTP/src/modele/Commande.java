package modele;

public class Commande {
	
	private int numClient;
	private Hamburger hamburger;
	private Accompagnement accompagnement;
	private Boisson boisson;
	private int numeroCommandeAttribuee;
	private static int numeroCommande = 0;
	
	public Commande(int numClient, Hamburger hamburger, Accompagnement accompagnement, Boisson boisson){
		this.numClient = numClient;
		this.hamburger = hamburger;
		this.accompagnement = accompagnement;
		this.boisson = boisson; 
		numeroCommande ++;
		this.numeroCommandeAttribuee = numeroCommande;
	}
	
	public static void initialiserNumeroCommande() {
		numeroCommande =0;
	}

	public int getNumClient() {
		return numClient;
	}

	public Hamburger getHamburger() {
		return hamburger;
	}

	public Accompagnement getAccompagnement() {
		return accompagnement;
	}

	public Boisson getBoisson() {
		return boisson;
	}

	public static int getNumeroCommande() {
		return numeroCommande;
	}
	
	public int getNumeroCommandeAttribuee() {
		this.numeroCommandeAttribuee = numeroCommande;
		return numeroCommandeAttribuee;
	}
}
