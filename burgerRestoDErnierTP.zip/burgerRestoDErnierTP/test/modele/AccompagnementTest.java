package modele;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AccompagnementTest {
	private String nom = "laPhrite";
	private Accompagnement accompagnement;
	

	@BeforeEach
	void setUp(){
		Assumptions.assumeTrue(nom != null);
		accompagnement = (Accompagnement) FabriqueAliment.creerAliment(AlimentMenu.ACCOMPAGNEMENT, nom);
	}

	@Test
	void testAccompagnement() {
		Assertions.assertNotNull(accompagnement);
	}
	
	@Test 
	void testGetNom() {
		Assertions.assertEquals(nom, accompagnement.getNom());
	}

}
