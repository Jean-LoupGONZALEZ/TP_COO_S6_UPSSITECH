package modele;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import controleur.ControlCreerProfil;

class BDClientTest {

	private BDClient bdClient;
	private String mdp = "oklm";
	private String prenom = "jean";
	private String nom = "jacques";
	private ControlCreerProfil controlCreerProfil = new ControlCreerProfil();
	private Client client;
	
	@BeforeEach
	void setUp() throws Exception {
		Assumptions.assumeTrue(mdp != null);
		Assumptions.assumeTrue(nom != null);
		Assumptions.assumeTrue(prenom != null);
		
		client = (Client) FabriqueProfil.creerProfil(ProfilUtilisateur.CLIENT, nom, prenom, mdp);

		bdClient = bdClient.getInstance();
	}

	@Test
	void testBDClient() {
		
	}
	
	@Test
	void testAjouterClient() {
		bdClient.ajouterClient(client);
	}
}
