package modele;

import org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class CommandeTest {
	//arguments necessaires à la creation d'un objet commande
	private Hamburger hamburger = new Hamburger("painDeFromage");
	private Accompagnement accompagnement = new Accompagnement("phrites");
	private Boisson boisson = new Boisson("eauDeGlou"); 
	int numClient = 1;
	
	private Commande commande; //on n'instancie pas pas commande car c'est qu'on va tester
	
	

	@BeforeEach
	void setUp(){
		Assumptions.assumeTrue(hamburger != null, "hamburger non null");
		Assumptions.assumeTrue(accompagnement != null, "accompagnement non null");
		Assumptions.assumeTrue(boisson != null, "boisson non null");
		Assumptions.assumeTrue(numClient == 1, "numClient non null");
		
		commande = new Commande(numClient, hamburger, accompagnement, boisson);
	}


	@Test
	void testCommande() {
		Assertions.assertNotNull(commande,"creation commande OK");
	}
	
	@Test
	void testInitialiserNumeroCommande() {
		commande = new Commande(numClient, hamburger, accompagnement, boisson);//pour que le num de commande soit != 0
		Commande.initialiserNumeroCommande();//remet a 0 num de commande
		Assertions.assertEquals(0, commande.getNumeroCommandeAttribuee());
	}
	
	@Test 
	void testGetNumeroCommandeAttribuee() {
		Commande.initialiserNumeroCommande();//car variable static, a chaque creation de commande, ne revient pas à 0
		
		commande = new Commande(numClient, hamburger, accompagnement, boisson);
		int numCommandeAtt = commande.getNumeroCommandeAttribuee();
		Assertions.assertEquals(1, numCommandeAtt);
		
		//creation d'une 2e commande donc le num attribue ++
		commande = new Commande(numClient, hamburger, accompagnement, boisson);
		numCommandeAtt = commande.getNumeroCommandeAttribuee();
		Assertions.assertEquals(2, numCommandeAtt);
	} 
	
	@Test
	void testGetNumeroCommande() {
		Commande.initialiserNumeroCommande();
		int numCommande = 0;
		Assertions.assertEquals(0, Commande.getNumeroCommande()); 
		
		//creation d'une 2e commande donc le num attribue ++
		commande = new Commande(numClient, hamburger, accompagnement, boisson);
		numCommande = Commande.getNumeroCommande();
		Assertions.assertEquals(1, numCommande);	
	}
	
	@Test
	void testGetAccompagnement() {
		Assertions.assertEquals(accompagnement, commande.getAccompagnement());
	}
	
	@Test
	void testGetBoisson() {
		Assertions.assertEquals(boisson, commande.getBoisson());
	}
	
	@Test
	void testGetHamburger() {
		Assertions.assertEquals(hamburger, commande.getHamburger());
	}
	
	@Test
	void testGetNumClient() {
		Assertions.assertEquals(numClient, commande.getNumClient());
	}
 
}
