package modele;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class BoissonTest {

	private static Boisson boisson;
	private static String nom = "glouglou";
	
	@BeforeAll
	void setUpBefore() {
		Assumptions.assumeTrue(nom != null);
		boisson = (Boisson) FabriqueAliment.creerAliment(AlimentMenu.BOISSON, nom);
		Assertions.assertNotNull(boisson);
	}
	
	@BeforeEach
	void setUp() throws Exception {
		
	}
	
	@Test
	void testGetNom() {
		String nomBoisson = boisson.getNom();
		Assertions.assertEquals(nom, nomBoisson);
	}

}
