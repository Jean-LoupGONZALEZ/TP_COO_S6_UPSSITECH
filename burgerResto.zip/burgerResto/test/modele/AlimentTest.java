package modele;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AlimentTest {
	
	private String nom = "légum";
	private Hamburger hamburger = new Hamburger(nom); //extends aliment

	@BeforeEach
	void setUp() throws Exception {
		Assumptions.assumeTrue(nom != null);
		Assumptions.assumeTrue(hamburger != null);
	}

	@Test
	void test() {
		Assertions.assertEquals("Aliment [nom=légum]", hamburger.toString());
	} 

}
