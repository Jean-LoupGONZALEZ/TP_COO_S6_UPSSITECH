package vueconsole;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import controleur.ControlVerifierIdentification;
import controleur.ControlVisualiserCommandeJour;
import modele.ProfilUtilisateur;
import modele.PropertyName;

public class BoundaryVisualiserCommandeJour implements PropertyChangeListener {
	//att
	private ControlVisualiserCommandeJour control;
	private ControlVerifierIdentification controlVerifierIdentification;
	private ControlVisualiserCommandeJour controlVisualiserCommandeJour;
	
	
	//constructeur
	public BoundaryVisualiserCommandeJour(ControlVisualiserCommandeJour control) {
		this.control = control;
	}
	
	//methodes
	public void propertyChange(PropertyChangeEvent evt) {
		String propertyName = evt.getPropertyName();
		PropertyName choix = PropertyName.valueOf(propertyName);
		switch(choix) {
			case ENREGISTRER_COMMANDE:
				Object o = evt.getNewValue();
				String [] labels = (String[])o;
	            String numeroCommande = labels[0];
	            String hamburger = labels[1];
	            String accompagnement = labels[2];
	            String boisson = labels[3];
	            Fichier.ecrire("Commande n°" + numeroCommande + ":" + hamburger + "'" + accompagnement + "'" + boisson);
	         break;
		default:
			System.out.println("Type de message inconnu");
			break;
		}
	}
	
	public void visualiserCommandeJour(int numeroCuisinier) {
		boolean cuisinierConnecte = control.verifierIdentification(numeroCuisinier, ProfilUtilisateur.PERSONNEL);
		if(cuisinierConnecte) {
			this.control.setListener(PropertyName.ENREGISTRER_COMMANDE.toString(), this);
		}
	}
}
