package controleur;

public class ControlVerifierCoordonneesBancaires {

	boolean verifierCoordonneesBancaires(int numeroCarte, int dateCarte) {
		return true;
	}
}
