package modele;

public enum ProfilUtilisateur {
	GERANT,
	PERSONNEL,
	CLIENT
}
