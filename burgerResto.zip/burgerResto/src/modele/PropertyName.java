package modele;

public enum PropertyName {
	ENREGISTRER_COMMANDE,
	SUPPRIMER_COMMANDE,
	VIDER_COMMANDE_JOUR
}
