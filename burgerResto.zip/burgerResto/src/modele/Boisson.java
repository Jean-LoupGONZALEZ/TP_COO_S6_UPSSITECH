package modele;

public class Boisson extends Aliment{
		
	public Boisson(String nom) {
		super(nom);
	}

}
