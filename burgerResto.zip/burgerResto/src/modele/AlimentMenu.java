package modele;

public enum AlimentMenu {
	HAMBURGER,
	ACCOMPAGNEMENT,
	BOISSON
}
