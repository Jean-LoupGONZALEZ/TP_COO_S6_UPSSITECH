package vueGraphique;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controleur.ControlCommander;

public class PanCommander extends JPanel implements IUseEnregistrerCoordonneesBancaires {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5897154507129012948L;
	// controleurs du cas + panel des cas inclus ou etendus en lien avec un acteur
	ControlCommander controlCommande;
	PanEnregistrerCoordonneesBancaires panEnregistrerCoordonneesBancaires;
	// les attributs metiers (ex : numClient)
	int numClient;
	int numeroHamburger = 0;
	int numeroAccompagnement = 0;
	int numeroBoisson =0;
	// Les elements graphiques :
	// Declaration et creation des polices d'ecritures
	Font policeTitre = new Font("Calibri",Font.BOLD,24);
	Font policeParagraphe = new Font("Calibri", Font.HANGING_BASELINE,16);
	// Declaration et creation des ComboBox
	private JComboBox<String> comboBoxHamburger = new JComboBox<>();
	private JComboBox<String> comboBoxBoisson = new JComboBox<>();
	private JComboBox<String> comboBoxAccompagnement = new JComboBox<>();
	// Declaration et creation des Button
	private JButton validerCommande = new JButton();
	private Box boxValiderChoix = Box.createHorizontalBox();
	// Declaration et creation des TextArea
	// Declaration et creation des Labels

	// Mise en page : les Box
	Box boxMiseEnPageCommande = Box.createVerticalBox();
	Box boxChoixHamburger = Box.createHorizontalBox();
	Box boxChoixBoisson = Box.createHorizontalBox();
	Box boxChoixAccompagnement = Box.createHorizontalBox();
	

	public PanCommander (
			// parametres pour l'initialisation des attributs metiers 
			// parametres correspondants au controleur du cas + panels 
			// des cas inclus ou etendus en lien avec un acteur
			ControlCommander controlCommande, PanEnregistrerCoordonneesBancaires panEnregistrerCoordonneesBancaire
		) {
		// initialisation des attributs metiers 
		// initilaisation du controleur du cas + panels 
		// des cas inclus ou etendus en lien avec un acteur
		this.controlCommande = controlCommande; 
		this.panEnregistrerCoordonneesBancaires= panEnregistrerCoordonneesBancaire; 
	}

	//Methode d'initialisation du panel
	public void initialisation() {
		// mise en forme du panel (couleur, ...)
		setBackground(Color.YELLOW);
		// creation des differents elements graphiques (JLabel, Combobox, Button, TextAera ...)
		JLabel texteCommander = new JLabel("Votre menu");
		texteCommander.setFont(policeTitre);
		JLabel texteHamburger = new JLabel("Choisissez votre hamburger");
		texteHamburger.setFont(policeParagraphe);
		comboBoxHamburger.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			numeroHamburger = comboBoxHamburger.getSelectedIndex();
			}
		});
		JLabel texteBoisson = new JLabel("Choisissez votre boisson");
		texteBoisson.setFont(policeParagraphe);
		comboBoxBoisson.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			numeroBoisson = comboBoxBoisson.getSelectedIndex();
			}
		});
		JLabel texteAccompagnement = new JLabel("Choisissez votre accompagnement");
		texteAccompagnement.setFont(policeParagraphe);
		comboBoxAccompagnement.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			numeroAccompagnement = comboBoxBoisson.getSelectedIndex();
			}
		});
		validerCommande.setText("Valider");
		validerCommande.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		if (
		numeroHamburger != 0 && numeroAccompagnement != 0
		&& numeroBoisson != 0) {
		validationCartePaiement();;;}}
		});
		// mise en page : placements des differents elements graphiques dans des Box
		boxMiseEnPageCommande.add(texteCommander);
		boxMiseEnPageCommande.add(Box.createRigidArea(new Dimension(0, 30)));
		boxChoixHamburger.add(texteHamburger);
		boxChoixHamburger.add(Box.createRigidArea(new Dimension(10, 0)));
		boxChoixHamburger.add(comboBoxHamburger);
		boxChoixBoisson.add(texteBoisson);
		boxChoixBoisson.add(Box.createRigidArea(new Dimension(10, 0)));
		boxChoixBoisson.add(comboBoxBoisson);
		boxChoixAccompagnement.add(texteAccompagnement);
		boxChoixAccompagnement.add(Box.createRigidArea(new Dimension(10, 0)));
		boxChoixAccompagnement.add(comboBoxAccompagnement);
		boxValiderChoix.add(validerCommande);
		// mise en page : placements des differentes box dans une box principale
		boxMiseEnPageCommande.add(boxChoixHamburger);
		boxMiseEnPageCommande.add(boxChoixBoisson);
		boxMiseEnPageCommande.add(boxChoixAccompagnement);
		boxMiseEnPageCommande.add(boxValiderChoix);
		// mise en page : ajout de la box principale dans le panel
		this.add(boxMiseEnPageCommande);
	}

	// Methode correspondante au nom du cas
	public void commander( int numClient) { 
		this.numClient = numClient;
		boolean clientConnecte = controlCommande.verifierIdentification(numClient);
		if(clientConnecte) {
			affichageMenu();
		}
	}

	// Methodes privees pour le bon deroulement du cas
	private void affichageMenu() {
		List<String> listeHamburger = controlCommande.donnerListeHamburger();
		List<String> listeAccompagnement = controlCommande.donnerListeAccompagnement();
		List<String> listeBoisson = controlCommande.donnerListeBoisson();
		System.out.println(listeHamburger);
		System.out.println(listeAccompagnement);
		System.out.println(listeBoisson);
		comboBoxHamburger.removeAllItems();
		comboBoxBoisson.removeAllItems();
		comboBoxAccompagnement.removeAllItems();
		comboBoxHamburger.addItem("");
		comboBoxBoisson.addItem("");
		comboBoxAccompagnement.addItem("");
		for(String hamburger : listeHamburger) {
			comboBoxHamburger.addItem(hamburger);
		}
		boxChoixHamburger.add(Box.createRigidArea(new Dimension(100, 0)));
		for(String boisson : listeBoisson) {
			comboBoxBoisson.addItem(boisson);
		}
		for(String accompagnement : listeAccompagnement) {
			comboBoxAccompagnement.addItem(accompagnement);
		}
	}
	
	@Override
	public void retourEnregistrerCoordonneesBancaire(boolean carteValide) {
		this.panEnregistrerCoordonneesBancaires.setVisible(false);
		if(carteValide) this.enregistrerCommande(carteValide);
	}
	
	private void validationCartePaiement() {
		boolean carteRenseignee = controlCommande.verifierExistenceCarteBancaire(numClient);
		if (!carteRenseignee) {
			boxMiseEnPageCommande.setVisible(false);
			panEnregistrerCoordonneesBancaires.setVisible(true);
			this.repaint();
			panEnregistrerCoordonneesBancaires.enregistrerCoordonneesBancaires(numClient, this);
			} else
			this.enregistrerCommande(carteRenseignee);
			}
	
	
	private void enregistrerCommande(boolean carteRenseignee) {
		
	}
}

