package vueGraphique;

import java.awt.Color;

import javax.swing.JPanel;

public class PanHistorique extends JPanel {
	// controleurs du cas + panel des cas inclus ou etendus en lien avec un acteur
	// les attributs metiers (ex : numClient)

	// Les elements graphiques :
	// Declaration et creation des polices d'ecritures
	// Declaration et creation des ComboBox
	// Declaration et creation des Button
	// Declaration et creation des TextArea
	// Declaration et creation des Labels

	// Mise en page : les Box

	public PanHistorique (
			// parametres pour l'initialisation des attributs metiers 
			// parametres correspondants au controleur du cas + panels 
			// des cas inclus ou etendus en lien avec un acteur
		) {
		// initialisation des attributs metiers 
		// initilaisation du controleur du cas + panels 
		// des cas inclus ou etendus en lien avec un acteur
	}

	//Methode d'initialisation du panel
	public void initialisation() {
		// mise en forme du panel (couleur, ...)
		setBackground(Color.GREEN);
		// creation des differents elements graphiques (JLabel, Combobox, Button, TextAera ...)

		// mise en page : placements des differents elements graphiques dans des Box
		// mise en page : placements des differentes box dans une box principale
		// mise en page : ajout de la box principale dans le panel
	}

	// Methode correspondante au nom du cas
	public void historique( /*parametres metiers*/ ) { 
	}

	// Methodes privees pour le bon deroulement du cas
}
