package vueGraphique;

public interface IUseEnregistrerCoordonneesBancaires {
	public void retourEnregistrerCoordonneesBancaire(boolean carteValide);
}
