module burgerResto {
	requires org.junit.jupiter.api;
	requires java.desktop;
	
}